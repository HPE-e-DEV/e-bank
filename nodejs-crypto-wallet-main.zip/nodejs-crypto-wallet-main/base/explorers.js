module.exports = {
    avalanche: 'https://snowtrace.io',
    avalanche_testnet: 'https://testnet.snowtrace.io',
    bsc: 'https://bscscan.com',
    bsc_testnet: 'https://testnet.bscscan.com'
}