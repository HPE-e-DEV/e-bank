module.exports = {
    avalanche: 'AVAX',
    avalanche_testnet: 'tAVAX',
    bsc: 'BNB',
    bsc_testnet: 'tBNB'
}