module.exports = {
    avalanche: 'https://api.avax.network/ext/bc/C/rpc',
    avalanche_testnet: 'https://api.avax-test.network/ext/bc/C/rpc',
    bsc: 'https://bsc-dataseed1.binance.org/',
    bsc_testnet: 'https://data-seed-prebsc-1-s1.binance.org:8545/'
}