### nodejs-crypto-wallet

Para el vídeo de la segunda parte es necesario instalar los siguientes paquetes en las versiones que se indican para que funcione:

- @truffle/hdwallet-provider@2.1.12
- ethers@5.6.9
- evm-bn@1.1.2
